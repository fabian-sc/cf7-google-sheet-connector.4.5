<div class="cd-faq-items">
	<ul id="basics" class="cd-faq-group">
		<li class="content-visible">
			<a class="cd-faq-trigger" href="#0"><?php echo esc_html( __( 'Field List - ', 'gsconnector' ) ); ?><span class="pro">Available In Pro</span></a>
			<div class="cd-faq-content" style="display: block;">
				<div class="gs-demo-fields gs-second-block">
                  <h2><span class="gs-info"><?php echo esc_html( __( 'Map mail tags with custom header name and save automatically to google sheet. ', 'gsconnector')); ?> </span></h2>
					<?php $this->display_form_fields( $form_id ); ?>
				</div>
			</div>
		</li>
	</ul>
</div>			
			