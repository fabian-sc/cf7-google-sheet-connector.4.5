<div class="cd-faq-items">
	<ul id="basics" class="cd-faq-group">
		<li class="content-visible">
			<a class="cd-faq-trigger" href="#0"><?php echo esc_html( __( 'Custom Mail Tags ', 'gsconnector' ) ); ?></a>
			<div class="cd-faq-content" style="display: block;">
				<div class="gs-demo-fields gs-third-block">
					<?php $this->display_form_custom_tag( $form_id ); ?>
				 </div>
			</div>
		</li>
	</ul>
</div>
